package threads;

import network.NetworkConnection;
import network.NetworkNode;
import state.BrokerState;

import java.io.Closeable;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Map;

public class ListeningThread extends ServerThread implements Closeable {
    private final BrokerState state;
    private ServerSocket serverSocket;

    public ListeningThread(Map<String, String> settings, BrokerState state) {
        super(settings);
        this.state = state;
    }

    @Override
    protected void preexecute() throws IOException {
        serverSocket = new ServerSocket(Integer.parseInt(settings.get("PORT")));
    }

    @Override
    protected boolean execute() {
        try {
            Socket socket = serverSocket.accept();
            NetworkNode node = new NetworkNode(socket.getInetAddress().toString(), socket.getPort());

            System.out.println("New connection from node: " + node);

            NetworkConnection nc = new NetworkConnection(node, socket);

            WorkingThread t = new WorkingThread(settings, nc, state);
            t.start();
        } catch (Exception ex) {
            if (!serverSocket.isClosed()) {
                ex.printStackTrace();
            }
        }
        return true;
    }

    @Override
    protected void postexecute_on_success() {

    }

    @Override
    protected void postexecute_on_exception(Exception ex) {

    }

    @Override
    public void close() throws IOException {
        serverSocket.close();
    }
}
