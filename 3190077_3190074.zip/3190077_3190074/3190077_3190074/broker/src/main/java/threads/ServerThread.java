package threads;

import java.io.EOFException;
import java.io.IOException;
import java.util.Map;

abstract class ServerThread extends Thread {
    protected final Map<String, String> settings;
    protected boolean running;

    public ServerThread(Map<String, String> settings) {
        this.settings = settings;
    }

    public void run() {
        super.run();

        try {
            preexecute();

            do {
                synchronized (settings) {
                    running = settings.get("RUNNING").equals("true");
                }

                if (execute() == false) {
                    break;
                }
            } while (running);

            postexecute_on_success();
        } catch (Exception ex) {
            if (!(ex instanceof EOFException)) {
                ex.printStackTrace();
            }
                postexecute_on_exception(ex);
        }
    }

    protected abstract void preexecute() throws IOException;

    protected abstract boolean execute() throws IOException;

    protected abstract void postexecute_on_success();

    protected abstract void postexecute_on_exception(Exception ex);
}

