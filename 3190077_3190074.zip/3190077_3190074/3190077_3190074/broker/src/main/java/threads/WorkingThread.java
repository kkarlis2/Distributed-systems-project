package threads;

import network.MessageHandler;
import network.NetworkConnection;
import network.messages.*;
import org.apache.commons.lang3.StringUtils;
import state.BrokerState;

import java.io.IOException;
import java.util.List;
import java.util.Map;

public class WorkingThread extends ServerThread {
    private NetworkConnection nc;
    private MessageHandler handler;
    private final BrokerState state;
    private boolean connectionStateful = false;
    private String connectionUsername = null;


    public WorkingThread(Map<String, String> settings, NetworkConnection nc, BrokerState state) {
        super(settings);
        this.nc = nc;
        this.handler = new MessageHandler(nc);
        this.state = state;
    }

    @Override
    protected void preexecute() {

    }

    @Override
    protected void postexecute_on_success() {
        if (connectionStateful) {
            state.processDisconnect(connectionUsername);
        }
    }

    @Override
    protected void postexecute_on_exception(Exception ex) {
        if (connectionStateful) {
            state.processDisconnect(connectionUsername);
        }
    }

    @Override
    protected boolean execute() throws IOException {
        MessageHandler.MessageType t = handler.readMessageType();

        if (t == MessageHandler.MessageType.REGISTER) {
            RegisterMessage registerMessage = handler.readRegisterMessage();
            System.out.println("Register message received with username: " + registerMessage.username);

            state.process(registerMessage);

            handler.sendCommand(settings.get("BROKER_IPS"));
            return false;
        }

        if (t == MessageHandler.MessageType.CONNECTION_REQUEST) {
            ConnectionRequestMessage message = handler.readConnectionRequestMessage();
            System.out.println("Connection request received with username: " + message.username);
            state.process(message, nc);
            connectionStateful = true;
            connectionUsername = message.username;
        }

        if (t == MessageHandler.MessageType.SUBSCRIBE) {
            SubscribeMessage message = handler.readSubscribeMessage();
            System.out.println("Subscribe request: " + message);

            state.process(message); // register

            List<BaseMessage> messages = state.messages.get(message.topic);

            int total = messages.size();

            handler.sendCommand(total + "");

            for (int i=0;i<total;i++) {
                BaseMessage m = messages.get(i);

                if (m instanceof TextMessage) {
                    TextMessage mm = (TextMessage)m;
                    handler.sendTextMessage(mm.topic, mm.data);
                }

                if (m instanceof FileMessage) {
                    FileMessage mm = (FileMessage)m;
                    handler.sendFile(mm.topic, mm.URI);
                }
            }
        }


        if (t == MessageHandler.MessageType.UNSUBSCRIBE) {
            UnsubscribeMessage message = handler.readUnsubscribeMessage();

            System.out.println("Unsubscribe request: " + message);
            state.process(message);
        }


        if (t == MessageHandler.MessageType.COMMAND) {
            CommandMessage cmdMessage = handler.readCommandMessage();
            if (cmdMessage.command.equalsIgnoreCase("TOPICS")) {
                String topics = StringUtils.join(state.messages.keySet(), "|");
                handler.sendCommand(topics);
            }
        }

        if (t == MessageHandler.MessageType.TEXT) {
            TextMessage message = handler.readTextMessage();
            System.out.println("Message received: " + message);
            state.process(message);

        }

        if (t == MessageHandler.MessageType.FILE) {
            FileMessage message= handler.readFileMessage();

            message.receive("cache" + settings.get("NODE_ID"), nc.input);

            System.out.println("File message received: " + message);
            state.process(message);

        }


        return true;
    }
}
