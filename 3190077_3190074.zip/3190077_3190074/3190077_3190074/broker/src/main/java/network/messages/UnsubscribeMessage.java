package network.messages;

public class UnsubscribeMessage extends BaseMessage {
    public final String topic;
    public final String username;

    public UnsubscribeMessage( String username, String topic) {

        this.username = username;
        this.topic = topic;
    }

    @Override
    public String toString() {
        return "UnsubscribeMessage{" +
                "topic='" + topic + '\'' +
                ", username='" + username + '\'' +
                '}';
    }
}
