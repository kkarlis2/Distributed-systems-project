package network.messages;

public class SubscribeMessage extends BaseMessage {
    public final String topic;
    public final String username;

    public SubscribeMessage(String username, String topic) {

        this.username = username;
        this.topic = topic;
    }

    @Override
    public String toString() {
        return "SubscribeMessage{" +
                "topic='" + topic + '\'' +
                ", username='" + username + '\'' +
                '}';
    }
}
