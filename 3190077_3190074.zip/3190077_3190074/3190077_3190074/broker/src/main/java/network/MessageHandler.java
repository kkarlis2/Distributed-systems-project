package network;

import network.messages.*;

import java.io.IOException;

public class MessageHandler {

    public enum MessageType {
        REGISTER,
        TEXT,
        FILE,
        COMMAND,
        CONNECTION_REQUEST,
        SUBSCRIBE,
        UNSUBSCRIBE,
    }


    public final NetworkConnection connection;

    public MessageHandler(NetworkConnection connection) {
        this.connection = connection;
    }

    public void sendRegister(String username) throws IOException {
        connection.output.writeUTF("REGISTER");
        connection.output.writeUTF(username);
        connection.output.flush();
    }


    public void sendConnectionRequest(String username) throws IOException {
        connection.output.writeUTF("CONNECTION_REQUEST");
        connection.output.writeUTF(username);
        connection.output.flush();
    }

    public void sendSubscribeRequest(String username, String topic) throws IOException {
        connection.output.writeUTF("SUBSCRIBE");
        connection.output.writeUTF(username);
        connection.output.writeUTF(topic);
        connection.output.flush();
    }

    public void sendUnsubscribeRequest(String username, String topic) throws IOException {
        connection.output.writeUTF("UNSUBSCRIBE");
        connection.output.writeUTF(username);
        connection.output.writeUTF(topic);
        connection.output.flush();
    }

    public void sendCommand(String command) throws IOException {
        connection.output.writeUTF("COMMAND");
        connection.output.writeUTF(command);
        connection.output.flush();
    }

    public void sendTextMessage(String topic, String text) throws IOException {
        connection.output.writeUTF("TEXT");
        connection.output.writeUTF(topic);
        connection.output.writeUTF(text);
        connection.output.flush();
    }


    public MessageType readMessageType() throws IOException {
        String prefix = connection.input.readUTF();
        if (prefix.equalsIgnoreCase("REGISTER")) {
            return MessageType.REGISTER;
        }
        if (prefix.equalsIgnoreCase("COMMAND")) {
            return MessageType.COMMAND;
        }
        if (prefix.equalsIgnoreCase("TEXT")) {
            return MessageType.TEXT;
        }
        if (prefix.equalsIgnoreCase("FILE")) {
            return MessageType.FILE;
        }
        if (prefix.equalsIgnoreCase("SUBSCRIBE")) {
            return MessageType.SUBSCRIBE;
        }
        if (prefix.equalsIgnoreCase("UNSUBSCRIBE")) {
            return MessageType.UNSUBSCRIBE;
        }
        if (prefix.equalsIgnoreCase("CONNECTION_REQUEST")) {
            return MessageType.CONNECTION_REQUEST;
        }

        throw new IllegalArgumentException("Invalid message type or connection lost");
    }

    public RegisterMessage readRegisterMessage() throws IOException {
        String data = connection.input.readUTF();
        return new RegisterMessage(data);
    }

    public ConnectionRequestMessage readConnectionRequestMessage() throws IOException {
        String data = connection.input.readUTF();
        return new ConnectionRequestMessage(data);
    }

    public SubscribeMessage readSubscribeMessage() throws IOException {
        String username = connection.input.readUTF();
        String topic = connection.input.readUTF();
        return new SubscribeMessage(username, topic);
    }

    public UnsubscribeMessage readUnsubscribeMessage() throws IOException {
        String username = connection.input.readUTF();
        String topic = connection.input.readUTF();
        return new UnsubscribeMessage(username, topic);
    }

    public CommandMessage readCommandMessage() throws IOException {
        String data = connection.input.readUTF();
        return new CommandMessage(data);
    }

    public TextMessage readTextMessage() throws IOException {
        String topic = connection.input.readUTF();
        String data = connection.input.readUTF();
        return new TextMessage(topic, data);
    }

    public void sendFile(String topic, String filename) throws IOException {
        connection.output.writeUTF("FILE");
        connection.output.writeUTF(topic);
        connection.output.writeUTF(filename);
        connection.output.flush();
    }

    public FileMessage readFileMessage() throws IOException {
        String topic = connection.input.readUTF();
        String data = connection.input.readUTF();
        return new FileMessage(topic, data);
    }






}
