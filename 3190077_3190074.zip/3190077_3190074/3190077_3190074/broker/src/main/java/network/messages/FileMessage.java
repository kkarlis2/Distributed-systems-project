package network.messages;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class FileMessage extends BaseMessage {
    public static final int BLOCK_SIZE = 8*1024;
    public String topic;
    public final String URI;

    public FileMessage(String topic, String URI) {
        this.topic = topic;
        this.URI = URI;
    }

    public boolean fileExists(String prefix) {
        File file = new File(prefix + "/" + URI);
        return file.exists();
    }

    public void send(String prefix, ObjectOutputStream os) throws IOException {
        File file = new File(prefix + "/" + URI);

        FileInputStream fileInputStream = new FileInputStream(file);

        long length = file.length();
        long packets = length/BLOCK_SIZE;

        os.writeLong(length);
        os.flush();



        for (long i=0;i<packets;i++) {
            byte [] block = new byte[BLOCK_SIZE];

            int sent = 0;

            while (sent < BLOCK_SIZE) {
                int n = fileInputStream.read(block, 0, BLOCK_SIZE-sent);
                sent += n;
            }

            os.write(block);
            os.flush();
        }

        if (length % BLOCK_SIZE > 0) {
            int missing = (int) length % BLOCK_SIZE;
            byte [] block = new byte[missing];

            int sent = 0;

            while (sent < missing) {
                int n = fileInputStream.read(block, 0, missing-sent);
                sent += n;
            }

            os.write(block);
            os.flush();
        }
    }

    public void receive(String prefix, ObjectInputStream is) throws IOException {
        long length = is.readLong();
        long packets = length/BLOCK_SIZE;

        File file = new File(prefix + "/" + URI);

        FileOutputStream os = new FileOutputStream(file);

        for (long i=0;i<packets;i++) {
            byte [] block = new byte[BLOCK_SIZE];

            int read = 0;

            while (read < BLOCK_SIZE) {
                int n = is.read(block, read, BLOCK_SIZE-read);
                read+=n;
            }

            os.write(block);
            os.flush();
        }

        if (length % BLOCK_SIZE > 0) {
            int missing = (int) length % BLOCK_SIZE;
            byte [] block = new byte[missing];


            int read = 0;

            while (read < missing) {
                int n = is.read(block, read, missing-read);
                read+=n;
            }

            os.write(block);
            os.flush();
        }

        os.close();
    }

    @Override
    public String toString() {
        return "FileMessage{" +
                "topic='" + topic + '\'' +
                ", data='" + URI + '\'' +
                '}';
    }
}
