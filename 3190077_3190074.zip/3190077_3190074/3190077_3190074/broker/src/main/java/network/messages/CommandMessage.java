package network.messages;

public class CommandMessage extends BaseMessage {
    public final String command;

    public CommandMessage(String command) {
        this.command = command;
    }
}
