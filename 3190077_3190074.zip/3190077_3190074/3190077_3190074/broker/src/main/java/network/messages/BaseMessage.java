package network.messages;

public abstract class BaseMessage {
}
