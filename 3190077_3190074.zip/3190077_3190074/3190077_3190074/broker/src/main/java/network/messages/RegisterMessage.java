package network.messages;

public class RegisterMessage extends BaseMessage {
    public final String username;

    public RegisterMessage(String username) {
        this.username = username;
    }
}
