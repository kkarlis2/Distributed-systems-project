package network;

import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class NetworkNode {
    public final String host;
    public final Integer port;
    public final List<NetworkConnection> connectionList = new ArrayList<>();

    public NetworkNode(String host, Integer port) {
        this.host = host;
        this.port = port;
    }

    public NetworkConnection connect() throws IOException {
        Socket s = new Socket(host, port);

        NetworkConnection conn = new NetworkConnection(this, s);

        connectionList.add(conn);

        return conn;
    }

    public boolean isConnected() {
        return !connectionList.isEmpty();
    }

    public void disconnect() throws IOException {
        for (NetworkConnection connection : connectionList) {
            try {
                connection.close();
            } catch (Exception ex) {

            }
        }

        connectionList.clear();
    }

    @Override
    public String toString() {
        return "NetworkNode{" +
                "host='" + host + '\'' +
                ", port=" + port + '}';
    }
}
