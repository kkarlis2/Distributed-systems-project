package network;

import java.io.Closeable;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class NetworkConnection implements Closeable {
    public final Socket socket;
    public final ObjectInputStream input;
    public final ObjectOutputStream output;
    public final NetworkNode networkNode;
    public final boolean successful;

    public NetworkConnection(NetworkNode networkNode, Socket s) throws IOException {
        this.networkNode = networkNode;
        this.socket  = s;
        this.output = new ObjectOutputStream(s.getOutputStream());
        this.output.flush();
        this.input = new ObjectInputStream(s.getInputStream());
        successful = true;

    }

    @Override
    public void close() throws IOException {
        if (successful) {
            this.input.close();
            this.output.close();
            socket.close();
        }
    }

}
