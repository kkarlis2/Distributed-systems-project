package network.messages;

public class ConnectionRequestMessage extends BaseMessage {
    public final String username;

    public ConnectionRequestMessage(String username) {
        this.username = username;
    }
}
