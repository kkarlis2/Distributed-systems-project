package network.messages;

public class TextMessage extends BaseMessage {
    public final String topic;
    public final String data;

    public TextMessage(String topic, String data) {

        this.topic = topic;
        this.data = data;
    }

    @Override
    public String toString() {
        return "TextMessage{" +
                "topic='" + topic + '\'' +
                ", data='" + data + '\'' +
                '}';
    }
}
