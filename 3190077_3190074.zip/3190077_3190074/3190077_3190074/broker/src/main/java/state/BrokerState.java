package state;

import network.MessageHandler;
import network.NetworkConnection;
import network.messages.*;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.util.*;

public class BrokerState {
    private int tick = 0;
    public final Set<String> registeredNodes = new HashSet<>(); // registered usernames
    public final HashMap<String, NetworkConnection> onlineNodes = new HashMap<>(); // topic : messages
    public final HashMap<String, Set<String>> subscribers = new HashMap<>(); // topic : usernames
    public final HashMap<String, List<BaseMessage>> messages = new HashMap<>(); // topic : messages
    private Map<String, String> settings;


    public BrokerState( Map<String, String> settings) {
        this.settings = settings;
    }

    public synchronized void print() {
        String t = String.format("tick: %5d \t", tick);
        String p = String.format("             \t");
        System.out.println(t + "Registered: " + StringUtils.join(registeredNodes, ","));
        System.out.println(p + "Online    : " + StringUtils.join(onlineNodes.keySet(), ","));
        System.out.println(p + "Topics    : ");
        for (String topic : messages.keySet()) {
            System.out.println(p + "\t" + topic + " => " + subscribers.get(topic) + ", messages: " + messages.get(topic).size());
        }
        tick++;
    }

    public synchronized void process(RegisterMessage registerMessage) {
        registeredNodes.add(registerMessage.username);
    }

    public synchronized void process(ConnectionRequestMessage message, NetworkConnection nc) {
        onlineNodes.put(message.username, nc);
    }

    public synchronized void processDisconnect(String connectionUsername) {
        onlineNodes.remove(connectionUsername);
    }

    public synchronized void process(SubscribeMessage message) {
        if (!messages.containsKey(message.topic)) {
            messages.put(message.topic, new ArrayList<>());
        }

        if (!subscribers.containsKey(message.topic)) {
            subscribers.put(message.topic, new HashSet<>());
        }

        subscribers.get(message.topic).add(message.username);
    }

    public synchronized void process(UnsubscribeMessage message) {
        subscribers.get(message.topic).remove(message.username);
    }

    public synchronized void process(TextMessage message) throws IOException {
        if (!messages.containsKey(message.topic)) {
            messages.put(message.topic, new ArrayList<>());
        }

        if (!subscribers.containsKey(message.topic)) {
            subscribers.put(message.topic, new HashSet<>());
        }

        messages.get(message.topic).add(message);

        for (String sub : subscribers.get(message.topic)) {
            MessageHandler handler = new MessageHandler(onlineNodes.get(sub));
            handler.sendTextMessage(message.topic, message.data);
        }
    }

    public void process(FileMessage message) throws IOException {
        if (!messages.containsKey(message.topic)) {
            messages.put(message.topic, new ArrayList<>());
        }

        if (!subscribers.containsKey(message.topic)) {
            subscribers.put(message.topic, new HashSet<>());
        }

        messages.get(message.topic).add(message);

        for (String sub : subscribers.get(message.topic)) {
            MessageHandler handler = new MessageHandler(onlineNodes.get(sub));
            handler.sendFile(message.topic, message.URI);

            message.send("cache" + settings.get("NODE_ID"), handler.connection.output);
        }

    }
}
