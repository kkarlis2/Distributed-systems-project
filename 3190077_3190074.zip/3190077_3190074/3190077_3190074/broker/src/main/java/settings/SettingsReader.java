package settings;

import org.apache.commons.lang3.StringUtils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SettingsReader {

    private final String[] args;

    public SettingsReader(String[] args) {

        this.args = args;
    }

    public Map<String, String> read(String filename) throws IOException, URISyntaxException {
        URL resource = getClass().getClassLoader().getResource(filename);
        File file = new File(resource.toURI());

        Map<String, String> settings = new HashMap<>();

        // ----------------------------- SETTINGS --------------------------
        settings.put("NODE_ID", args[0]);
        settings.put("PORT", "1000" + args[0]);
        settings.put("RUNNING", "true");
        // -----------------------------------------------------------------

        try (BufferedReader br = new BufferedReader(new FileReader(file)) ){
            String st;

            List<String> ip_list = new ArrayList<>();

            int port = 10001;

            while ((st = br.readLine()) != null) {
                if (!st.startsWith("#")) {
                    ip_list.add(st.trim() + ":" + port++);
                }
            }

            String data = StringUtils.join(ip_list, "|");

            settings.put("BROKER_IPS", data);
        }


        return settings;
    }
}
