package broker;

import state.BrokerState;
import threads.ListeningThread;

import java.io.Closeable;
import java.io.IOException;
import java.util.Map;

public class BrokerServer extends Thread implements Closeable {
    public final BrokerState state;
    public final Map<String, String> settings;

    public BrokerServer(Map<String, String> settings) {
        this.settings = settings;
        state = new BrokerState(settings);
    }

    public void run() {
        try {
            boolean ok;

            ListeningThread listeningThread = new ListeningThread(settings, state);

            listeningThread.start();

            do {
                synchronized (settings) {
                    ok = settings.get("RUNNING").equals("true");
                }

                state.print();

                if (ok) {
                    Thread.sleep(1000);
                }
            } while (ok);

            listeningThread.close();

            listeningThread.join();
        } catch (Exception ex) {
            if (! (ex instanceof InterruptedException)) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    public void close() throws IOException {

    }

    public void shutdown()  {
        synchronized (settings) {
            settings.put("RUNNING", "false");
        }

        try {
            System.out.println("waiting for listening thread to exit ... ");
            this.interrupt();
            this.join();
        } catch (Exception ex) {

        }
    }
}
