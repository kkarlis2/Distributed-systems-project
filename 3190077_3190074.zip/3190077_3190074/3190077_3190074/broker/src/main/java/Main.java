import broker.BrokerServer;
import settings.SettingsReader;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Map;

public class Main {
    public static void main(String [] args) throws IOException, URISyntaxException {
        if (args.length != 1 || args[0].length() != 1) {
            throw new IllegalArgumentException("Please provide a valid BROKER ID and the number of total brokers. Valid values = { 0 - 9 }");
        }

        String filename = "broker_addresses.txt";
        SettingsReader sr = new SettingsReader(args);
        Map<String, String> settings = sr.read(filename);

        System.out.println("======================================================");
        System.out.println("              Broker " + settings.get("NODE_ID") + ", port:" + settings.get("PORT"));
        System.out.println("======================================================");
        System.out.println(settings);


        try (BrokerServer server = new BrokerServer(settings)) {

            Thread printingHook = new Thread(() -> server.shutdown());
            Runtime.getRuntime().addShutdownHook(printingHook);


            server.start();

            server.join();

            System.out.println("Broker " + settings.get("NODE_ID") + " shutdown successful");
        } catch (Exception ex) {
            ex.printStackTrace();

            System.out.println("Broker " + settings.get("NODE_ID") + " exited with error");
        }
    }
}
