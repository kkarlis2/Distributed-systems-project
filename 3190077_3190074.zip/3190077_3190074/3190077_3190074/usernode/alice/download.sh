#/bin/bash
wget -nd -H -p -A jpg,jpeg,png,gif -e robots=off http://boards.4chan.org/mu/
