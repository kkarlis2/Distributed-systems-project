import network.NetworkNode;
import settings.SettingsReader;
import usernode.Usernode;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class Main {
    public static void main(String [] args) throws IOException, URISyntaxException {
        Scanner scanner = new Scanner(System.in);

        if (args.length != 1) {
            throw new IllegalArgumentException("Please provide a valid USERNAME");
        }

        String filename = "broker_addresses.txt";
        SettingsReader sr = new SettingsReader(args);
        Map<String, String> settings = sr.read(filename);

        System.out.println("======================================================");
        System.out.println("              Usernode " + settings.get("NODE_ID"));
        System.out.println("======================================================");
        System.out.println(settings);

        try (Usernode usernode = new Usernode(settings)) {
            System.out.println("Registering via " + settings.get("BROKER_IPS"));
            usernode.register();
            System.out.println("Registration successful, broker list updated to: " + settings.get("BROKER_IPS"));

            System.out.println("Known brokers:  ");

            for (NetworkNode node : usernode.brokerNodes) {
                System.out.println("\t" + node);
            }

            System.out.println("Retrieving topics ... ");
            Set<String> topics = usernode.getTopics();

            System.out.println("Available topics: ");

            if (!topics.isEmpty()) {
                for (String s : topics) {
                    System.out.println(" - " + s);
                }
            } else {
                System.out.println(" There are no available topics right now ");
            }

            while (true) {
                System.out.print("Type the topic you want to chat (type a new one in order to create): ");

                String topic = scanner.nextLine().trim().toLowerCase();

                if (topic.isEmpty()) {
                    continue;
                }

                if (topic.equalsIgnoreCase("quit") || topic.equalsIgnoreCase("exit") || topic.equalsIgnoreCase("q") || topic.equalsIgnoreCase("e")) {
                    break;
                }

                System.out.println("entering chatroom " + topic);

                usernode.chat(topic);

                System.out.println("exiting chatroom " + topic);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("An error has occured: " + ex.getMessage());
        }

    }
}
