package ui;

import network.MessageHandler;
import network.NetworkConnection;
import network.NetworkNode;
import network.messages.*;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class AndroidForm {

    private final Map<String, String> settings;
    private final NetworkNode node;
    private final String topic;
    private final NetworkConnection nc;
    private final MessageHandler handler;
    private final String username;


    class IncomingThread extends Thread {
        public IncomingThread() {
            System.out.println("Starting background thread for chat ");
        }

        public void run() {
            try {
                while (!Thread.currentThread().isInterrupted()) {
                    if  (nc.input.available() > 0) {
                        MessageHandler.MessageType t = handler.readMessageType();

                        if (t == MessageHandler.MessageType.TEXT) {
                            TextMessage message = handler.readTextMessage();
                            System.out.println(message);
                        }

                        if (t == MessageHandler.MessageType.FILE) {
                            String prefix = username.toLowerCase();

                            FileMessage message = handler.readFileMessage();

                            message.receive(prefix + "/downloads/", nc.input);

                            System.out.println(message);
                        }
                    }
                    Thread.sleep(200);
                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {

            }
        }

    }

    public AndroidForm(Map<String, String> settings, NetworkNode node, String topic) {
        System.out.println("Chatting about topic " + topic + " on " + node.host + ":" + node.port + " as " + settings.get("NODE_ID"));
        this.settings = settings;
        this.node = node;
        this.topic = topic;
        this.nc = node.connectionList.get(0);
        this.username = settings.get("NODE_ID");
        handler = new MessageHandler(nc);
    }


    public void display() throws IOException, InterruptedException {
        System.out.println("===============================================================");
        System.out.println("Subscribing to " + topic);

        handler.sendSubscribeRequest(username, topic);

        if (handler.readMessageType() != MessageHandler.MessageType.COMMAND) {
            throw new IllegalArgumentException("Protocol error");
        }

        CommandMessage total = handler.readCommandMessage();

        System.out.println("Message history: " + total.command +  " messages. ");

        int n = Integer.parseInt(total.command);

        for (int i=0;i<n;i++) {
            MessageHandler.MessageType t = handler.readMessageType();

            if (t == MessageHandler.MessageType.TEXT) {
                TextMessage message = handler.readTextMessage();
                System.out.println("Message received: " + message);
            }

            if (t == MessageHandler.MessageType.FILE) {
                FileMessage message = handler.readFileMessage();
                System.out.println("Message received: " + message);
            }
        }


        IncomingThread thread = new IncomingThread();
        thread.start();

        main();

        System.out.println("Unsubscribing from " + topic);

        handler.sendUnsubscribeRequest(username, topic);
        System.out.println("===============================================================");

        thread.interrupt();
        thread.join();
    }

    private void main() throws IOException {
        Scanner scanner = new Scanner(System.in);

        System.out.println("------------------------------");
        System.out.println("       Welcome to " + topic);
        System.out.println("------------------------------");

        System.out.println(" - Type quit|exit|q to exit ");
        System.out.println(" - Type FILE <path> to send a file");
        System.out.println(" - Type anything else to send a text message");

        while (true) {
            String msg = scanner.nextLine().trim();

            if (msg.equalsIgnoreCase("quit") || msg.equalsIgnoreCase("exit") || msg.equalsIgnoreCase("q")) {
                break;
            }

            if (msg.isEmpty()) {
                continue;
            }

            if (!msg.toLowerCase().startsWith("file ")) {
                handler.sendTextMessage(topic, username + " says: " + msg);
            } else {
                msg = msg.substring("file ".length());

                String URI = msg;


                FileMessage fm = new FileMessage(topic, URI);

                String prefix = username.toLowerCase();

                if (fm.fileExists(prefix)) {
                    handler.sendFile(topic, URI);
                    fm.send(prefix, nc.output);
                } else {
                    System.out.println("File not found.");
                }
            }
        }
    }
}
