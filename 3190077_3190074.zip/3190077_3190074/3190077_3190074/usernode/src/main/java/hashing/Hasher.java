package hashing;

import network.NetworkNode;
import org.apache.commons.codec.digest.DigestUtils;

import java.util.*;

public class Hasher {
    public String hash(String data) {
        String md5Hex = DigestUtils.md5Hex(data).toUpperCase();
        return md5Hex;
    }

    // https://www.geeksforgeeks.org/modulus-of-two-hexadecimal-numbers/
    private long hexaModK(String N, String k) {
        // Store all possible
        // hexadecimal digits
        HashMap<Character, Integer> map
                = new HashMap<>();

        // Iterate over the range ['0', '9']
        for (char i = '0'; i <= '9'; i++) {
            map.put(i, i - '0');
        }
        map.put('A', 10);
        map.put('B', 11);
        map.put('C', 12);
        map.put('D', 13);
        map.put('E', 14);
        map.put('F', 15);

        // Convert given string to long
        long m = Long.parseLong(k, 16);

        // Base to get 16 power
        long base = 1;

        // Store N % K
        long ans = 0;

        // Iterate over the digits of N
        for (int i = N.length() - 1;
             i >= 0; i--) {

            // Stores i-th digit of N
            long n
                    = map.get(N.charAt(i)) % m;

            // Update ans
            ans = (ans + (base % m * n % m) % m) % m;

            // Update base
            base = (base % m * 16 % m) % m;
        }

        return ans;
    }

    public NetworkNode findBroker(List<NetworkNode> nodes, String topic) { // returns network node for the topic
        if (nodes.isEmpty()) {
            throw new IllegalArgumentException("No node found. Hasher find broker failed");
        }

        if (nodes.size() == 1 || topic.isEmpty()) {
            return nodes.get(0);
        }

        String htopic = hash(topic);

        List<String> hashes = new ArrayList<>();
        Map<String, NetworkNode> assoc = new HashMap<>();

        for (int i=0;i<nodes.size();i++) {
            hashes.add(nodes.get(i).hash);
            assoc.put(nodes.get(i).hash, nodes.get(i));
        }


        Collections.sort(hashes);

        for (int i=0;i<nodes.size();i++) {
            if (htopic.compareTo(hashes.get(i)) <= -1) {
                return assoc.get(hashes.get(i));
            }
        }

        String hbrokers = Integer.toHexString(nodes.size());

        long result = hexaModK(htopic, hbrokers);

        return nodes.get((int)result);
    }
}
