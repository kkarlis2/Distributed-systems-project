package network;

import hashing.Hasher;

import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class NetworkNode {
    public final String host;
    public final Integer port;
    public final String hash;
    public final List<NetworkConnection> connectionList = new ArrayList<>();

    public NetworkNode(String host, Integer port) {
        this.host = host;
        this.port = port;
        this.hash = new Hasher().hash(host + port);
    }

    public NetworkNode(String broker_ips) {
        this(broker_ips.split(":")[0], Integer.parseInt(broker_ips.split(":")[1]));
    }

    public NetworkConnection connect() throws IOException {
        Socket s = new Socket(host, port);

        NetworkConnection conn = new NetworkConnection(this, s);

        connectionList.add(conn);

        return conn;
    }

    public boolean isConnected() {
        return !connectionList.isEmpty();
    }

    public void disconnect() throws IOException {
        for (NetworkConnection connection : connectionList) {
            try {
                connection.close();
            } catch (Exception ex) {

            }
        }

        connectionList.clear();
    }

    public NetworkConnection getDefaultConnection() {
        if (connectionList.isEmpty()) {
            return null;
        } else {
            return connectionList.get(0);
        }
    }


    @Override
    public String toString() {
        return "NetworkNode{" +
                "host='" + host + '\'' +
                ", port=" + port +
                ", hash='" + hash + "\'}";
    }
}
