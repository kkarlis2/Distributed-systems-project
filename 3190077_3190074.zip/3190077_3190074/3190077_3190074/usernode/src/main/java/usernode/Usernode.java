package usernode;

import hashing.Hasher;
import network.MessageHandler;
import network.NetworkConnection;
import network.NetworkNode;

import java.io.Closeable;
import java.io.IOException;
import java.util.*;
import ui.AndroidForm;

public class Usernode implements Closeable {
    private final NetworkNode initialBroker;
    private final Hasher hasher = new Hasher();
    public final Map<String, String> settings;
    public final List<NetworkNode> brokerNodes = new ArrayList<>();



    public Usernode(Map<String, String> settings) {

        this.settings = settings;

        initialBroker = new NetworkNode(this.settings.get("BROKER_IPS"));
    }

    @Override
    public void close() throws IOException {
        for (NetworkNode node : brokerNodes) {
            node.disconnect();
        }
    }

    public void register() throws IOException {
        String broker_ips = null;

        try (NetworkConnection connection = initialBroker.connect()) {
            MessageHandler handler = new MessageHandler(connection);
            handler.sendRegister(settings.get("NODE_ID"));

            MessageHandler.MessageType type = handler.readMessageType();

            if (type != MessageHandler.MessageType.COMMAND) {
                throw new IllegalArgumentException("protocol error");
            }

            broker_ips = handler.readCommandMessage().command;
        }

        settings.put("BROKER_IPS", broker_ips);

        String[] addresses = broker_ips.split("[|]");

        for (String addr : addresses) {
            System.out.println("- Creating a tcp channel to " + addr + " .... ");

            NetworkNode networkNode = new NetworkNode(addr);

            NetworkConnection brokerConnection = networkNode.connect();

            brokerNodes.add(networkNode);

            MessageHandler handler = new MessageHandler(brokerConnection);

            handler.sendConnectionRequest(settings.get("NODE_ID"));
        }
    }

    public Set<String> getTopics() throws IOException {
        Set<String> topics = new HashSet<>();

        for (NetworkNode node:  brokerNodes) {
            NetworkConnection connection = node.getDefaultConnection();
            MessageHandler handler = new MessageHandler(connection);

            handler.sendCommand("TOPICS");

            MessageHandler.MessageType type = handler.readMessageType();

            if (type != MessageHandler.MessageType.COMMAND) {
                throw new IllegalArgumentException("protocol error");
            }

            String data = handler.readCommandMessage().command.trim();

            System.out.println("Topics retrieved from broker " + connection.networkNode.host +":" + connection.networkNode.port + " => '" + data + "'");

            if (!data.isEmpty()) {
                for (String s : data.split("[|]")) {
                    topics.add(s + " (broker: " + connection.networkNode.host +":" + connection.networkNode.port + ")");
                }
            }
        }

        return topics;

    }

    public void chat(String topic) throws IOException, InterruptedException {
        NetworkNode node = hasher.findBroker(brokerNodes, topic);

        System.out.println("Selected server: " + node);

        AndroidForm a = new AndroidForm(settings, node, topic);
        a.display();
    }
}
